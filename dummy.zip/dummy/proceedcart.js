// const cart = require('./script.js');
import cart from './script.js';
console.log("Cart Items:", cart);
