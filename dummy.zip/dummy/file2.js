// file2.js
const myVariable = require('./file1');

console.log(myVariable); // Output: Hello from file1!
