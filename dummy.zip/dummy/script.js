// Mock Product Array
const products = [
    { id: 1, name: "Product 1", price: 100 },
    { id: 2, name: "Product 2", price: 150 },
    { id: 3, name: "Product 3", price: 200 },
];

// Cart Array

const cart = [];

// Elements
const productsContainer = document.getElementById("products");
const cartContainer = document.getElementById("cart");
const proceedButton = document.getElementById("proceedToCart");

// Render Products
function renderProducts() {
    productsContainer.innerHTML = "";
    products.forEach((product) => {
        const productCard = document.createElement("div");
        productCard.classList.add("card");
        productCard.innerHTML = `
        <span>${product.name} - $${product.price}</span>
        <button onclick="addToCart(${product.id})">Add to Cart</button>
      `;
        productsContainer.appendChild(productCard);
    });
}

// Add to Cart
function addToCart(productId) {
    const product = products.find((item) => item.id === productId);

    cart.push(product);
    renderCart();

}

// Render Cart
function renderCart() {
    cartContainer.innerHTML = "";
    cart.forEach((item) => {
        const cartCard = document.createElement("div");
        cartCard.classList.add("card");
        cartCard.innerHTML = `<span>${item.name} - $${item.price}</span>
        <button onclick="removeFromCart(${item.id})">Remove</button>`;
        cartContainer.appendChild(cartCard);
    });
}
function removeFromCart(productId) {
    const index = cart.findIndex((item) => item.id === productId);
    if (index > -1) {
        cart.splice(index, 1);
    }
    renderCart();
}



// Export Cart Array
proceedButton.addEventListener("click", () => {
    exportCartArray();
});

// Export Function
function exportCartArray() {
    const cartData = JSON.stringify(cart);
    localStorage.setItem("cart", cartData);
    alert("Cart data exported. Go to proceedcart.js to access it.");
}



window.addToCart = addToCart;
window.removeFromCart = removeFromCart;
// On Load
renderProducts();
renderCart();




export default cart;
// module.exports = cart;
