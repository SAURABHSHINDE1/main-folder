// file1.js
const myVariable = "Hello from file1!";
module.exports = myVariable;
