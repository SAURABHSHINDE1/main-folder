var product=[
    {
        Product_image:[
            "https://m.media-amazon.com/images/I/51ZYURwOOwL._SX569_.jpg",
            "",
            ""
        ],
        Name:"Go well Solid Satin Silk Pillow Covers Pack of 2 for Hair & Skin-with Satin Scrunchies for Women Stylish|scrunchies for Women 3-Piece|Silk Pillow case(Rose taupe)600TC",
        Brand_name:"GO WELL",
        Price:"265",
        Rating:3.5 ,
        Rating_count: "7339 ratings",
        MRP:"₹499",
        Discount:"-47%", 
        colour:"Rosetaupe",
        day:" Monday, 6 January",
        time:"1 hr 42 mins",
        delivery:"Delivering to Shirdi 423109 - Update location",
        productBrought:"2K+ bought ",
        Offers:[
            {
            Offer_name:"Partner Offer",
            Offer:"Save 2% on 2 of every 2 Qualifying…",
            },
            {
            Offer_name:"Bank Offer",
            Offer:"Upto ₹2,000.00 discount on select…",
            },
            {
              Offer_name:"Partner Offer",
              Offer:"Save 2% on 2 of every 2 Qualifying…",
              },
              {
              Offer_name:"Bank Offer",
              Offer:"Upto ₹2,000.00 discount on select…",
              },
            
        ],
        Features:[
            {
              Title:"Brand",
              Desc:"GO WELL",
            },
            {
              Title:"Pillow Type",
              Desc:"Bed Pillow",
            },
            {
              Title:"Material",
              Desc:"Polyester, satin",
            },
            {
               Title:"Size",
               Desc:"Standard",
            },
            {
               Title:"Product Dimensions",
               Desc:"72L x 48W Centimeters",
            },
            {
               Title:"Colour",
               Desc:"Rosetaupe",
            },
            {
                Title:"Recommended",
                Desc:"home",
             },

            ],
            
            Uses_For_Product:[
               {
                Title:"Closure Type",
                Desc:"Envelope",
               },
               {
                Title:"Special Featurer",
                Desc:"Cooling, Breathable",
               },
               {
                Title:"Product Care Instructions",
                Desc:"Machine Wash",
               },
            ],
            
        
        About_this_item:[
          
          
               " ELEVATE YOUR BEAUTY SLEEP : This 100% polyester satin silk pillow cover protect delicate hair from scratches, creases and tugs, helping to reduce split ends and ensuring a night of restorative beauty sleep.",
  
               "LEAVE SKIN HYDRATED : Experience the next generation of revolutionary fabric, highly advanced satin pillow cover fabric. while other materials may tug at your hair follicles and strip your skin of natural, important oils, satin pillow cover isn't as drying as cotton. satin pillow cover is like a godsend for your skin. your skin of natural, important oils, . satin pillow cover is like a godsend for your skin",

               "EXCLUSIVE USER FEELING : Go Well Satin Pillow Cover Envelope closure end design prevents your pillows from escaping during your sweet dream. No zipper, this pillow covers has an easy on and off design to bring you a unique and pleasant experience",

                "FRESH AND MODERN EXPRESSION : Go Well crisp, even-textured satin pillow cover are both soft and durable, coaxing out a good night's sleep",

                "Easy Care: High-quality satin Pillow Cover is sturdier and more durable than silk pillow cases, which need professional care. Turn Go Well satin pillowcase inside out, place it inside a mesh laundry bag and wash with a mild detergent",
                
            
        ],
    },
];  


const products = [
  {
      productid:1,
      Product_image: [
          "https://m.media-amazon.com/images/I/71x6Pty7rLL._SX522_.jpg",
      ],
      Name: "BELOXY Plastic Kids Barbie Doll Playset/Gudiya/Doll for Kids with Foldable Hand,Makeup,Clothes & Beauty Doll Accessories for Kids(Multicolor) Doll (1)",
      Brand_name: "Visit the BELOXY Store",
      Price: "₹649",
      Rating: 4.9,
      Rating_count: "39 ",
      MRP: "₹1399",
      Discount: "(-54%)",
      colour: "Ivory White",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on...",
          },
      ],
      About_this_item: [
          "Included Components: Pack of 1 Doll With Beauty Playset.",
          "Color: Multicolor | Material: Plastic",
          "Special Feature: Light weighted, attractive, colorful, vibrant, soft and easy to carry",
          "Age Range Description: 3 Years and up",
          "Is Assembly Required: Yes",
      ],
  },
  {
      productid:2,
      Product_image: [
          "https://m.media-amazon.com/images/I/71JdlF7JKIL._SX522_.jpg",
      ],
      Name: "Barbie Doll (Multicolour)",
      Brand_name: "Visit the BELOXY Store",
      Price: "₹1,958",
      Rating: 4.2,
      Rating_count: "29,272 ",
      MRP: "₹1,999",
      Discount: "(-2%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on...",
          },
          {
              Offer_name: "No Cost EMI",
              Offer: "Upto ₹88.19 EMI interest savings on Amazon Pay ICICI…",
          },
      ],
      About_this_item: [
          "Toys and Games",
          "Barbie doll and her puppy are ready for an adventure around the world with this travel set that includes more than 10 accessories",
          "Barbie doll has luggage (a roller suitcase, backpack and pet bag), travel items (like a sleep mask and neck pillow), necessities (like snacks, toothpaste and a cell phone) and more",
          "She's dressed to go anywhere wearing a denim dress with white shoes and her puppy is adorable with a matching collar; Kids will love decorating the pair's luggage with the included sheet of iconic travel stickers that help express personal style and inspire imaginative stories",
      ],
  },
  {
      productid:3,
      Product_image: [
          "https://m.media-amazon.com/images/I/61zPxWcy6FL._SX522_.jpg",
      ],
      Name: "Barbie Fashion Doll with Straight Blonde Hair Wearing Removable Pink One-Shoulder Dress & Shoes with Logo Print",
      Brand_name: "Visit the BELOXY Store",
      Price: "₹447",
      Rating: 4.5,
      Rating_count: "334 ",
      MRP: "₹499",
      Discount: "(-10%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
      ],
      About_this_item: [
          "​Barbie doll is ready for anything in a versatile outfit that is right on trend!",
          "She wears a removable pink dress with one-shoulder silhouette and Barbie logos in black and white",
          "Pink shoes complete the look for a signature barbiecore statement!",
          "Long, straight blonde hair can be styled for anything!",
          "Ready for all kinds of stories and styling, Barbie doll makes a great gift for kids ages 3 years and older!",
      ],
  },
  {
      productid:4,
      Product_image: [
          "https://m.media-amazon.com/images/I/71cXXL-KIaL._SX522_.jpg",
      ],
      Name: "Barbie Doll (11.5 inches) with Colorful Butterfly Logo Print Red Dress & Strappy Heels, Great Gift for Ages 3 Years Old & Up ",
      Brand_name: "Visit the Barbie Store",
      Price: "₹449",
      Rating: 4.3,
      Rating_count: "1,360 ",
      MRP: "₹499",
      Discount: "(-2%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
      ],
      About_this_item: [
          "​Wearing a colorful butterfly and Barbie logo print dress with a pair of strappy heels, Barbie doll really makes a style statement.",
          "The shoulder straps and piping on the bodice and hem really make the print pattern pop!",
          "Barbie fans can collect all the dolls with dresses in a variety of exciting colors (each sold separately, subject to availability).",
          "Barbie fans can collect all the dolls with dresses in a variety of exciting colors (each sold separately, subject to availability)",
          
      ],
  },
  {
      productid:5,
      Product_image: [
          "https://m.media-amazon.com/images/I/7173OPkQpjL._SX522_.jpg",
      ],
      Name: "Barbie Dolls 3 Wearing Logo Print Dresses, Toy for Kids Ages 3 and Up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹476",
      Rating: 4.5,
      Rating_count: "959",
      MRP: "₹499",
      Discount: "(-5%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
      ],
      About_this_item: [
          "These Barbie dolls can go from day to night in brightly colored, versatile looks!",
          "Choose from dolls featuring a variety of skin tones, eye colors, hair colors and styles.",
          "​Each wears a dress with a unique silhouette, color scheme and an allover Barbie logo print",
          "Matching heels add another bright pop of color.",
          "Kids can tell all kinds of stories because when a girl plays with Barbie, she imagines everything she can become!",
      ],
  },
  {
      productid:6,
      Product_image: [
          "https://m.media-amazon.com/images/I/71NiLCjfZ2L._SX522_.jpg",
      ],
      Name: "Barbie Dolls 1 Wearing Logo Print Dresses, Toy for Kids Ages 3 and Up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹440",
      Rating: 4.5,
      Rating_count: "959",
      MRP: "₹459",
      Discount: "(-27%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹13.20 cashback as Amazon Pay Balance when…",
          },
      ],
      About_this_item: [
          "These Barbie dolls can go from day to night in brightly colored, versatile looks!",
          "Choose from dolls featuring a variety of skin tones, eye colors, hair colors and styles.",
          "​Each wears a dress with a unique silhouette, color scheme and an allover Barbie logo print",
          "Matching heels add another bright pop of color.",
          "Kids can tell all kinds of stories because when a girl plays with Barbie, she imagines everything she can become!",
      ],
  },
  {
      productid:7,
      Product_image: [
          "https://m.media-amazon.com/images/I/61GKv1WZsNL._SX522_.jpg",
      ],
      Name: "Barbie Nurse Blonde Doll (12-in/30.40-cm) with Scrubs Featuring a Medical Tool Print Top & Pink Pants, White Shoes & Stethoscope Accessory, Great Gift for Ages 3 Years Old & Up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹699",
      Rating: 4.7,
      Rating_count: "5,212",
      MRP: "₹999",
      Discount: "(-30%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹20.97 cashback as Amazon Pay Balance when…",
          },
      ],
      About_this_item: [
          "Wearing cute scrubs featuring a medical-tool print top, pink pants and white shoes, Barbie nurse doll (12-in/30.40-cm) is ready make her rounds and check on patients!",
          "Place the stethoscope around Barbie nurse doll's neck for realistic play.",
          "Explore a world of creative storytelling fun with the Barbie nurse doll!",
          "Makes a great gift for kids 3 years old and up, especially those interested in caretaking and helping others",
      ],
  },
  {
      productid:8,
      Product_image: [
          "https://m.media-amazon.com/images/I/61d8+K8oIcL._SX522_.jpg",
      ],
      Name: "Barbie Pop Star Doll Dressed in Iridescent Skirt with Microphone and Pink Hair, Gift for 3 to 7 Year Olds",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,099",
      Rating: 4.7,
      Rating_count: "5,212",
      MRP: "₹1,250",
      Discount: "(-5%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹32.97 cashback as Amazon Pay Balance when…",
          },
      ],
      About_this_item: [
          "​Dream big with Barbie career dolls!",
          "Barbie pop star doll is ready for the stage in an outfit that will help her shine -- a sparkly silvery top, iridescent skirt, trendy purple shoes and long pink hair.",
          "This musician doll can rock a performance with her microphone stand and removable microphone.",
          "Barbie pop star doll makes a perfect gift for young music lovers and musicians",
          "Explore all the Barbie career dolls and playsets because when a girl plays with Barbie, she imagines everything she can become (each sold separately, subject to availability)",
      ],
  },
  {
      productid:9,
      Product_image: [
          "https://m.media-amazon.com/images/I/31jw0EI6jQL._SX300_SY300_QL70_FMwebp_.jpg",
      ],
      Name: "Barbie® Doll, Fun & Fancy™ Hair with Extra-Long Colorful Blonde Hair and Glossy Pink Dress, 10 Hair and Fashion Play Accessories",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,713",
      Rating: 4.7,
      Rating_count: "80",
      MRP: "₹1,999",
      Discount: "(-14%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹51.42 cashback as Amazon Pay Balance when…",
          },
          {
              Offer_name: "No Cost EMI",
              Offer: "Upto ₹77.17 EMI interest savings on Amazon Pay ICICI…",
          },
      ],
      About_this_item: [
          "Devoted to all things hair, the Barbie Fun & Fancy Hair collection showcases glam dolls with colorful hairstyles. Plus, the 10 included fashion and styling pieces allow for endless customization",
          "Barbie doll has 8.5 inches of extra-long playable blonde hair with fantasy pops of color! She wears a glossy pink minidress with white earrings and strappy golden shoes.",
          "Kids can easily transform her look with mix-and-match fashions! She comes with an extra dress printed with cat graphics, an extra pair of heels and a purse.",
          "Styling accessories include a cat ear headband with hair extensions, a clip with a hair extension, two barrettes, one headband with hair buns and one set of hair ties.",
          "Once kids have created their hairstyles, they can use the brush to comb out Barbie doll’s tresses and repeat for hours of fun. From colorful updos to layered braids, the possibilities are endless!",
      ],
  },
  {
      productid:10,
      Product_image: [
          "https://m.media-amazon.com/images/I/31q8B-cp+oL._SY300_SX300_.jpg",
      ],
      Name: "Barbie Doll (11.5 inches) with Colorful Butterfly Logo Print Blue Dress & Strappy Heels, Great Gift for Ages 3 Years Old & Up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹370",
      Rating: 4.3,
      Rating_count: "1,360",
      MRP: "₹499",
      Discount: "(-18%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹11.10 cashback as Amazon Pay Balance when…",
          },
          
      ],
      About_this_item: [
          "Wearing a colorful butterfly and Barbie logo print dress with a pair of strappy heels, Barbie doll really makes a style statement.",
          "​The shoulder straps and piping on the bodice and hem really make the print pattern pop!",
          "Barbie fans can collect all the dolls with dresses in a variety of exciting colors (each sold separately, subject to availability)",
          "Barbie fans can collect all the dolls with dresses in a variety of exciting colors (each sold separately, subject to availability)",
          
      ],
  },
  {
      productid:11,
      Product_image: [
          "https://m.media-amazon.com/images/I/31NmDXyVH+L._SY300_SX300_.jpg",
      ],
      Name: "Barbie Doll and Accessories, 65th Anniversary Commemorative Doll with Blonde Hair, Pink and White Striped Dress with Matching Heels",
      Brand_name: "Visit the Barbie Store",
      Price: "₹854",
      Rating: 4.6,
      Rating_count: "91",
      MRP: "₹999",
      Discount: "(-15%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹25.62 cashback as Amazon Pay Balance when…",
          },
          
      ],
      About_this_item: [
          "Barbie celebrates its 65th anniversary with a super cute and oh-so-collectible Barbie doll in a timeless fashion!",
          "Barbie doll wears a sweet off-shoulder pink and white dress with a black contrast bow at the neckline.",
          "​Dressed in signature Barbie pink, her outfit pays homage to the original Barbie doll's striped swimsuit",
          "​Perfectly coordinated accessories add polish to her sweet look: pearlescent earrings and bubblegum pink heels!",
          
      ],
  },
  {
      productid:12,
      Product_image: [
          "https://m.media-amazon.com/images/I/71al0bPbuoL._SY879_.jpg",
      ],
      Name: "Barbie & Stacie Doll Set with 2 Pet Dogs & Accessories, Dolls with Blonde Hair & Blue Eyes, Summer Clothes",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,750",
      Rating: 4.7,
      Rating_count: "3,347",
      MRP: "₹2,299",
      Discount: "(-24%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹25.62 cashback as Amazon Pay Balance when…",
          },
          {
              Offer_name: "No Cost EMI",
              Offer: "Upto ₹78.78 EMI interest savings on Amazon Pay ICICI…",
          },
          
      ],
      About_this_item: [
          "​Play out sister bonding time with this doll set featuring Barbie and her younger sis, Stacie!",
          "​Their summer clothes and accessories are inspired by their looks in the animated movie, Barbie and Stacie to the Rescue.",
          "Always fabulous, big sis Barbie doll wears an off-the-shoulder, ruffle-collar dress and sneakers.",
          "​Sporty and adventurous, little sister Stacie doll wears a fun top, shorts, and sneakers.",
          "​Kids (3 years old and up) can play out family adventures with accessories like a camera, binoculars, summer hat, and two pet pups!",
          
      ],
  },
  {
      productid:13,
      Product_image: [
          "https://m.media-amazon.com/images/I/512Di0pExNL._SX300_SY300_QL70_FMwebp_.jpg",
      ],
      Name: "Barbie™ The Movie Doll Wearing Pink and White Gingham Dress with Daisy Chain Necklac",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,979",
      Rating: 4.7,
      Rating_count: "5,332",
      MRP: "₹2,299",
      Discount: "(-34%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹59.37 cashback as Amazon Pay Balance when…",
          },
          {
              Offer_name: "No Cost EMI",
              Offer: "Upto ₹89.13 EMI interest savings on Amazon Pay ICICI…",
          },
          
      ],
      About_this_item: [
          "Take home a part of Barbie The Movie with this collector Barbie doll! Wearing a pink gingham dress, she’s all set to have the best day ever in Barbie Land.",
          "Barbie doll models a vintage-inspired pink and white gingham dress with a matching belt and full, pleated skirt.",
          "Her long blond hair is styled in a half-up do and tied with a pink ribbon, perfectly showing off her daisy drop earrings.",
          "She looks just like film Barbie with her daisy chain necklace! An adorable pink bracelet and heart-adorned pink pumps complete her look",
          "This posable doll comes in collectible Barbie The Movie packaging. Check out the whole collection for more fantastic gift ideas! Each sold separately, subject to availability.",
          
      ],
  },
  {
      productid:14,
      Product_image: [
          "https://m.media-amazon.com/images/I/41kVl0+ELgL._SY300_SX300_.jpg",
      ],
      Name: "Barbie ​Blonde Doll with Pink and White Swimsuit, Sun Hat, Tote Bag and Beach-Themed Accessories",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,168",
      Rating: 4.7,
      Rating_count: "1,027",
      MRP: "₹1,199",
      Discount: "(-3%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹35.04 cashback as Amazon Pay Balance when…",
          },
          
      ],
      About_this_item: [
          "​Kick back at the beach with this Barbie doll! Her super cute fashion and themed accessories will inspire kids to dream up every kind of summer story under the sun",
          "Barbie doll wears a pretty pink and white striped swimsuit with a sheer polka dot sarong tied at the waist. Golden hoop earrings and peep-toe sandals add extra cuteness!",
          "Additional styling accessories include a wide-brimmed sun hat, cat-eye sunglasses, a golden necklace and a stacked bracelet.",
          "Her pink tote bag is perfect for storing her sunscreen lotion, lipstick and smartphone; the minty ice cream cone clips to her hand for realistic posing!",
          "​This Barbie beach doll makes a charming gift for all ocean and fashion lovers! Check out other Barbie dolls, toys and sets for more fun gift ideas. Each sold separately, subject to availability.",
          
      ],
  },
  {
      productid:15,
      Product_image: [
          "https://m.media-amazon.com/images/I/31HsN1n8-4L._SX300_SY300_QL70_FMwebp_.jpg",
      ],
      Name: "Barbie Scientist Doll (12 inches), Blue Hair, Color Block Dress, Lab Coat & Flats, Microscope Accessory, Great Gift for Ages 3 Years Old & Up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹699",
      Rating: 4.7,
      Rating_count: "1,099",
      MRP: "₹1,199",
      Discount: "(-36%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹20.97 cashback as Amazon Pay Balance when…",
          },
          
      ],
      About_this_item: [
          "Explore science career fun with the Barbie scientist doll!​",
          "​Wearing a color-block dress with lab coat (featuring a science-inspired logo) and flats, Barbie scientist doll (12 inches) has colorful blue hair and comes with goggles and a microscope to make a scientific discovery! ​",
          "Use the microscope for realistic play and to act out science experiments.​",
          "​Explore a world of creative storytelling fun with the Barbie scientist doll!​",
          "​Makes a great gift for kids 3 years old and up, especially those interested in science, experiments and are curious to learn!​.",
          
      ],
  },
  {
      productid:16,
      Product_image: [
          "https://m.media-amazon.com/images/I/4149Xegd88L._SX300_SY300_QL70_FMwebp_.jpg",
      ],
      Name: "Barbie Royal Doll with Pink and Blonde Fantasy Hair, Colorful Accessories, Pink Ombre Bodice and Butterfly-Print Skirt",
      Brand_name: "Visit the Barbie Store",
      Price: "₹989",
      Rating: 4.6,
      Rating_count: "180",
      MRP: "₹999",
      Discount: "(-1%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹29.67 cashback as Amazon Pay Balance when…",
          },
          
      ],
      About_this_item: [
          "Explore a fantasy land of magic and adventure with this charming collection of royal Barbie dolls!",
          "Barbie doll has two-tone pink and blonde hair and wears a beautifully detailed ombre bodice with a matching butterfly print skirt. ​",
          "She also comes with colorful accessories like a flower headband, necklace, and heels for dress-up fun!​",
          "Kids can discover other royals in the collection to inspire friendship stories and expand their imagined world!​",
          "From royals and mermaids to unicorns and more, Barbie fantasy dolls make an enchanting gift for kids!.",
          
      ],
  },
  {
      productid:17,
      Product_image: [
          "https://m.media-amazon.com/images/I/41bNXdCPaDL._SX300_SY300_QL70_FMwebp_.jpg",
      ],
      Name: "Barbie Baby Doctor Playset with Blonde Doll, 2 Infant Dolls, Exam Table and Accessories, Stethoscope, Chart and Mobile for Ages 3 and Up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,799",
      Rating: 4.5,
      Rating_count: "19,725",
      MRP: "₹1,800",
      Discount: "(-1%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹53.97 cashback as Amazon Pay Balance when…",
          },
          {
              Offer_name: "No Cost EMI",
              Offer: "Upto ₹81.03 EMI interest savings on Amazon Pay ICICI…",
          },
          
      ],
      About_this_item: [
          "​You can be a baby doctor with the Barbie Baby Doctor playset!",
          "​Includes baby doctor environment with Barbie Baby Doctor doll, 2 adorable baby doll patients and toy play pieces for examinations and caretaking.​",
          "Wearing light green 'scrubs' and with a stethoscope around her neck, Barbie Baby Doctor doll is ready to take care of her baby doll patients. Barbie notes in her chart: the babies are doing great!​",
          "​Toy play items include an examination table with lotion bottle and other accessories, overhead mobile and clear compartments for the 2 baby doll patients.​",
          "Explore a world of creative play and storytelling fun with the Barbie Baby Doctor Playset!",
          
      ],
  },
  {
      productid:18,
      Product_image: [
          "https://m.media-amazon.com/images/I/415UpxK4N-L._SX300_SY300_QL70_FMwebp_.jpg",
      ],
      Name: "Barbie Dreamtopia Mermaid Doll (13-inch) with Extra-Long Two-Tone Fantasy Hair, Hairbrush, Tiaras and Styling Accessories, Gift for Ages 3 and up",
      Brand_name: "Visit the Barbie Store",
      Price: "₹1,399",
      Rating: 4.7,
      Rating_count: "2,974",                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
      MRP: "₹1,599",
      Discount: "(-13%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹41.97 cashback as Amazon Pay Balance when…",
          },
         
          
      ],
      About_this_item: [
          "Brush Barbie mermaid doll's long, colorful hair, then style her look and take her on an undersea adventure!",
          "Styling accessories include a hairbrush, 2 tiaras, 2 barrettes and 2 comb clips that let kids design and create endless fairytale looks.",
          "Barbie mermaid doll's fantasy look features a bodice with gem-inspired details and a sparkling tail with a translucent purple fin.​",
          "This Barbie Dreamtopia doll makes a great gift for kids ages 3 years old and up, especially those that love hairstyling and mermaids!​",
          
      ],
  },
  {
      productid:19,
      Product_image: [
          "https://m.media-amazon.com/images/I/51L-x4iPZJL._SX522_.jpg",
      ],
      Name: "Barbie Fashion Doll with Straight Dark Burgundy Hair Wearing Removable Pink Tank Dress & Shoes with Logo Print",
      Brand_name: "Visit the Barbie Store",
      Price: "₹360",
      Rating: 4.5,
      Rating_count: "344",
      MRP: "₹599",
      Discount: "(-40%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹10.80 cashback as Amazon Pay Balance when…",
          },
          
          
      ],
      About_this_item: [
          "​Barbie doll is ready for anything in a versatile outfit that is right on trend!",
          "​She wears a removable pink dress with a tank silhouette and Barbie logos in black and white!​",
          "​Pink shoes complete the look for a signature barbiecore statement!",
          "​Long, straight hair colored dark burgundy can be styled for anything!​",
          "Ready for all kinds of stories and styling, Barbie doll makes a great gift for kids 3 years and older!",
          
      ],
  },
  {
      productid:20,
      Product_image: [
          "https://m.media-amazon.com/images/I/41cMu59jN9L._SX522_.jpg",
      ],
      Name: "Barbie Ballerina Doll, Blonde Fashion Doll Wearing Purple Removable Tutu, Posed with Ballet Arms & “en Pointe” Toe Shoes​",
      Brand_name: "Visit the Barbie Store",
      Price: "₹581",
      Rating: 4.5,
      Rating_count: "108",
      MRP: "₹641",
      Discount: "(-10%)",
      colour: "Multicolour",
      day: "Tuesday, 7 January",
      time: "3 hrs 10 mins",
      delivery: "Delivering to Pune 411001 - Update location",
      productBrought: "1K+ bought",
      name_mrp:"M.R.P:",
      Offers: [
          {
              Offer_name: "Bank Offer",
              Offer: "Up to ₹2,000.00 discount on select credit card...",
          },
          {
              Offer_name: "Partner Offer",
              Offer: "Get GST invoice and save up to 28% on business purchases.",
          },
          {
              Offer_name: "Cashback",
              Offer: "Upto ₹17.43 cashback as Amazon Pay Balance when…",
          },
          
          
      ],
      About_this_item: [
          "​Inspire dreams to step into the spotlight with Barbie ballerina dolls!",
          "Each fashion doll wears a flower-decorated bodice and removable sheer tutu in matching color.​",
          "​A classic top-knot bun is the perfect hairstyle for rehearsal or performance.",
          "​Ballet arms and 'en pointe' sculpted toe shoes add to the role-play and dancing fun!​",
          "​With a range of looks, kids can collect them all to choreograph playtime their way!",
          
      ],
  },
 
];

var abc=new URLSearchParams(window.location.search);
var id=abc.get("id");


// id=5;

var pro=products.find((prod)=> prod.productid==id);

product[0]=pro ;


var pname=document.getElementById('pname')
pname.innerText=product[0].Name;
console.log(pname)

var productbrand=document.getElementById('productbrand')
productbrand.innerText=product[0].Brand_name;
console.log(productbrand)

var Rate=document.getElementById('Rate')
Rate.innerText=product[0].Rating;
console.log(Rate)

var ratecount=document.getElementById('ratecount')
ratecount.innerText=product[0].Rating_count;
console.log(ratecount)

var productprice=document.getElementById('productprice')
productprice.innerText=product[0].Price;
console.log(productprice)

var productmrp=document.getElementById('productmrp')
productmrp.innerText=product[0].MRP;
console.log(productmrp)

// var bankoffer=document.getElementById('bankoffer')
// bankoffer.innerText=products[0].Offers[1].Offer;
// console.log(bankoffer)

// var partneroffer=document.getElementById('partneroffer')
// partneroffer.innerText=products[0].Offers[0].Offer;
// console.log(partneroffer)

// var featurebrand=document.getElementById('featurebrand')
// featurebrand.innerText=products[0].Features[0].Desc;
// console.log(featurebrand)

// var featf1=document.getElementById('featf1')
// featf1.innerText=products[0].Features[1].Title;
// console.log(featf1)

// var featf2=document.getElementById('featf2')
// featf2.innerText=products[0].Features[1].Desc;
// console.log(featf2)

// var featf3=document.getElementById('featf3')
// featf3.innerText=products[0].Features[2].Title;
// console.log(featf3)

// var featf4=document.getElementById('featf4')
// featf4.innerText=products[0].Features[2].Desc;
// console.log(featf4)

// var reccomend1=document.getElementById('reccomend1')
// reccomend1.innerText=products[0].Uses_For_Product[0].Title;
// console.log(reccomend1)

// var reccomend2=document.getElementById('reccomend2')
// reccomend2.innerText=products[0].Uses_For_Product[0].Desc;
// console.log(reccomend2)

// var reccomend3=document.getElementById('reccomend3')
// reccomend3.innerText=products[0].Uses_For_Product[1].Title;
// console.log(reccomend3)

// var reccomend4=document.getElementById('reccomend4')
// reccomend4.innerText=products[0].Uses_For_Product[1].Desc;
// console.log(reccomend4)

// var reccomend5=document.getElementById('reccomend5')
// reccomend5.innerText=products[0].Uses_For_Product[2].Title;
// console.log(reccomend5)

// var reccomend6=document.getElementById('reccomend6')
// reccomend6.innerText=products[0].Uses_For_Product[2].Desc;
// console.log(reccomend6)

// var desc1=document.getElementById('desc1')
// desc1.innerText=products[0].About_this_item[0]
// console.log(desc1)

// var desc2=document.getElementById('desc2')
// desc2.innerText=products[0].About_this_item[1]
// console.log(desc2)

// var desc3=document.getElementById('desc3')
// desc3.innerText=products[0].About_this_item[2]
// console.log(desc3)

// var desc4=document.getElementById('desc4')
// desc4.innerText=products[0].About_this_item[3]
// console.log(desc4)

// var desc5=document.getElementById('desc5')
// desc5.innerText=products[0].About_this_item[4]
// console.log(desc5)

var col=document.getElementById('col')
col.innerText=product[0].colour;
console.log(col)

var orderprice=document.getElementById('orderprice')
orderprice.innerText=product[0].Price;
console.log(orderprice)

var orderday=document.getElementById('orderday')
orderday.innerText=product[0].day;
console.log(orderday)

var ordertime=document.getElementById('ordertime')
ordertime.innerText=product[0].time;
console.log(ordertime)

var orderdelivery=document.getElementById('orderdelivery')
orderdelivery.innerText=product[0].delivery;
console.log(orderdelivery)

var productpeople=document.getElementById('productpeople')
productpeople.innerText=product[0].productBrought;
console.log(productpeople)

// var mainimage=document.getElementById('mainimage')
// mainimage.innerText=products[0].Product_image[0];
// console.log(mainimage)

var ratingstar = document.getElementById('ratingstar');

for(let i = 1; i < product[0].Rating; i++) {
    var star = document.createElement('i');
    // console.dir(star);
    star.className = "ri-star-fill"
    ratingstar.appendChild(star);
  }

if (ratingstar % 1 !== 0) {
    var star = document.createElement('i');
    star.className = "ri-star-half-fill"
    ratingstar.appendChild(star);
  } 

for(let i = 1; i < 5 - product[0].Rating; i++) {
        var star=document.createElement('i');
        // console.dir(star);
        star.className = "ri-star-line";
        ratingstar.appendChild(star);
}
  



 console.log(product[0].Offers.length);

 var lengthofoffer=product[0].Offers.length;

for(i=0; i<lengthofoffer; i++)
{
  var offerDiv=document.createElement('div');
  offerDiv.className="box";
  off.appendChild(offerDiv);

  var h4=document.createElement('h4');
  h4.innerText=product[0].Offers[i].Offer_name;
  offerDiv.appendChild(h4);

  var p=document.createElement('p');
  p.innerText=product[0].Offers[i].Offer;
  offerDiv.appendChild(p);
}



 console.log(product[0].About_this_item.length);

 var length=product[0].About_this_item.length;

 console.log(length);

 var about = document.getElementById('desc');

for(i=0; i<length; i++)
{

  var li=document.createElement('li');
  li.innerText=product[0].About_this_item[i];
  about.appendChild(li);

}

console.log(product[0].Features.length);
var len=product[0].Features.length;
console.log(len);
var tab=document.getElementById('tab');

for(i=0; i<len; i++)
{
  var tr=document.createElement('tr');
  tab.appendChild(tr)

  var th=document.createElement('th');
  th.innerText=product[0].Features[i].Title;
  tr.appendChild(th);

  var td=document.createElement('td');
  td.innerText=product[0].Features[i].Desc;
  tr.appendChild(td);
}

console.log(product[0].Features.length);
var len1=product[0].Features.length;
console.log(len1);
var tab1=document.getElementById('tab1');

for(i=0; i<len1; i++)
{
  var tr=document.createElement('tr');
  tab1.appendChild(tr)

  var th=document.createElement('th');
  th.innerText=product[0].Uses_For_Product[i].Title;
  tr.appendChild(th);

  var td=document.createElement('td');
  td.innerText=product[0].Uses_For_Product[i].Desc;
  tr.appendChild(td);
}






